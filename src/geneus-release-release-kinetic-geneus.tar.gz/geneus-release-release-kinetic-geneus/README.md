geneus [![Build Status](https://travis-ci.org/jsk-ros-pkg/geneus.svg?branch=master)](https://travis-ci.org/jsk-ros-pkg/geneus)
======

[hydro build status](http://www.ros.org/debbuild/hydro.html?q=geneus)

[indigo build status](http://www.ros.org/debbuild/indigo.html?q=geneus)

[jade build status](http://www.ros.org/debbuild/jade.html?q=geneus)
